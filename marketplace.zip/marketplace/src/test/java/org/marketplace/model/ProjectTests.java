package org.marketplace.model;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class ProjectTests {
	@Test
	public void testEmptyProject() {
		Project project = new Project();
		assertNotEquals(project.getId(), new Long(0L));
	}
	
	@Test
	public void testGoodProject() {
		Date date = new Date();
		Project project = new Project(123L, "frabjous", 12.34, date);
		assertEquals(project.getSellerId(), new Long(123L));
		assertEquals(project.getDescription(), "frabjous");
		assertEquals(project.getAmount(), new Double(12.34), 0.001);
		assertEquals(project.getExpiration(), date);
	}
	
	@Test
	public void testFurtureExpiration() throws Exception {
		Bid bid = new Bid(123L, 456L, 10.00);
		Date future = new Date();
		future.setTime(future.getTime() + 5);
		Project project = new Project(123L, "frabjous", 12.34, future);
		project.addNewBid(bid);
		assertEquals(project.getLowestBidAmount(), 10.00, 0.001);
	}
	
	@Test (expected = Exception.class)
	public void testPastExpiration() throws Exception {
		Bid bid = new Bid(123L, 456L, 10.00);
		Date past = new Date();
		past.setTime(past.getTime() - 5);
		Project project = new Project(123L, "frabjous", 12.34, past);
		project.addNewBid(bid);
		assertEquals(project.getLowestBidAmount(), 10.00, 0.001);
	}
}
