package org.marketplace.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;

import org.marketplace.model.Bid;
import org.marketplace.model.Buyer;
import org.marketplace.model.Project;
import org.marketplace.model.Seller;
import org.springframework.stereotype.Component;

/**
 * Represents the DAO and persistent store for the Marketplace application.  A few shortcuts
 * were used to get around the complexities of using a real backing store, but that is the
 * nature of example code.  In particular, the Bid and Project objects fake out the creation
 * of their id numbers by using AUTOINCREMENT.  Further, the Project and Bid objects would be
 * persisted after alteration (e.g., a new Bid is accepted for a Project).
 * 
 * @author ryonts
 *
 */
@Component
public class MarketplaceDAO {
	private static Map<Long, Bid> bids = new HashMap<>();
	private static Map<Long, Buyer> buyers = new HashMap<>();
	private static Map<Long, Project> projects = new HashMap<>();
	private static Map<Long, Seller> sellers = new HashMap<>();

	{
		String[][] bidList = {
				{ "1000", "1000", "122.00" },
				{ "1000", "1001", "121.00" },
				{ "1001", "1001", "12.50" },
				{ "1002", "1000", "40.00" },
				{ "1002", "1001", "38.00" },
				{ "1002", "1000", "37.50" },
		};
		for (String[] s : bidList) {
			Bid bid = new Bid(Long.parseLong(s[0]), Long.parseLong(s[1]), Double.parseDouble(s[2]));
			bids.put(bid.getId(), bid);
		}

		String[][] buyerList = {
				{ "1000", "Painters R Us" },
				{ "1001", "We Do Dishes" },
				{ "1002", "ABC Landscaping" },
		};
		for (String[] s : buyerList) {
			Buyer buyer = new Buyer(Long.parseLong(s[0]), s[1]);
			buyers.put(buyer.getId(), buyer);
		}

		String[][] projectList = {
				{ "1000", "paint my house", "123.00", "2018-07-01" },
				{ "1001", "wash my dishes", "15.50", "2018-07-04" },
				{ "1002", "mow my lawn", "40.10", "2018-07-02" },
		};
		for (String[] p : projectList) {
			try {
				Project project = new Project(Long.parseLong(p[0]), p[1], Double.parseDouble(p[2]), new SimpleDateFormat("yyyy-MM-dd").parse(p[3]));	
				projects.put(project.getId(), project);
			} catch (Exception e) { System.out.println(e.getMessage()); }
		}

		String[][] sellerList = {
				{ "1000", "Regina" },
				{ "1001", "Sammy" },
				{ "1002", "Tammy" },
		};
		for (String[] s : sellerList) {
			Seller seller = new Seller(Long.parseLong(s[0]), s[1]);
			sellers.put(seller.getId(), seller);
		}
	}
	
	public List<Project> getProjects() { return new ArrayList<Project>(projects.values()); }
	public void addProject(Project project) { projects.put(project.getId(), project); }
	public Project getProjectById(Long id) { return projects.get(id); }
	public void addBid(Bid bid) { bids.put(bid.getId(), bid); }
	public Bid getBidById(Long id) { return bids.get(id); }
}
