package org.marketplace.controller;

public class MarketplaceException  extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public MarketplaceException(String message) {
		super(message);
	}
}
