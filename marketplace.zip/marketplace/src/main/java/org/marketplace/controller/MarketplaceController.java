package org.marketplace.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.marketplace.controller.MarketplaceException;
import org.marketplace.repository.MarketplaceDAO;
import org.marketplace.model.Bid;
import org.marketplace.model.Project;

/**
 * Define controller that handles all ReST endpoints for Marketplace project
 * @author ryonts
 *
 * Uses a Repository to hold Buyers, Sellers, Projects, and Bids.  For this simple
 * example, the basic Spring annotations suffices to drive the full set of endpoints.
 */

@RestController
public class MarketplaceController {
	@Autowired
	private MarketplaceDAO marketplaceDAO;

	@GetMapping("/project")
	public List<Project> getProjects() {
		return marketplaceDAO.getProjects();
	}
	
	@PostMapping("/project")
	public @ResponseBody Project addProjects(@RequestBody Project project) {
		marketplaceDAO.addProject(project);
		return project;
	}

	@GetMapping("/project/{id}")
	public @ResponseBody Project getProject(@PathVariable("id") Long id) {
		Project project = marketplaceDAO.getProjectById(id);
		if (project == null)
			throw new MarketplaceException("No project exists with id of " + id);
		return project;
	}

	@GetMapping(value = "/project/{id}/bid")
	public @ResponseBody Double getLowestBid(@PathVariable("id") Long id) {
		Project project = marketplaceDAO.getProjectById(id);
		try {
			return project.getLowestBidAmount();
		} catch (Exception e) {
			throw new MarketplaceException(e.getMessage());
		}
	}

	@PostMapping("/project/{id}/bid")
	public @ResponseBody Bid submitBid(@PathVariable("id") Long id, @RequestBody Bid bid) {
		Project project = marketplaceDAO.getProjectById(id);
		try {
			project.addNewBid(bid);
		} catch (Exception e) {
			throw new MarketplaceException(e.getMessage());
		}
		marketplaceDAO.addBid(bid);
		return bid;
	}

	@PostMapping("/project/{id}/autobid")
	public @ResponseBody Bid submitAutoBid(@PathVariable("id") Long id, @RequestBody Bid bid) {
		Project project = marketplaceDAO.getProjectById(id);
		Double price = project.getAmount() - bid.getAmount();
		if (price < 0.00)
			throw new MarketplaceException("autobid amount greater than project cost");
		bid.setAmount(price);
		try {
			project.addNewBid(bid);
		} catch (Exception e) {
			throw new MarketplaceException(e.getMessage());
		}
		marketplaceDAO.addBid(bid);
		return bid;
	}
}
