package org.marketplace.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/** 
 * Represents a bid from a Seller in regard to a Buyer's Project.  The Bid must
 * associate the necessary pieces and have both a legitimate amount (less than or
 * equal to the current Projet cost) and occur prior to the expiration date of
 * the Project.
 * 
 * @author ryonts
 *
 */
@Entity
public class Bid {
	@Id
	private Long id;
	private Long project;
	private Long buyer;
	private Double amount;
	
	public Bid() {
		id = Bid.nextSequence();
	}
	public Bid(Long project, Long buyer, Double amount) {
		id = Bid.nextSequence();
		this.project = project;
		this.buyer = buyer;
		this.amount = amount;
	}
	
	public Long getId() { return id; }
	public Long getProject() { return project; }
	public Long getBuyer() { return buyer; }
	public Double getAmount() { return amount; }
	public void setAmount(Double amount) { this.amount = amount; }
	
	// ===== class methods to fake out the real database action of autoincrement =====
	private static long sequence = 1000;
	private static long nextSequence() {
		return sequence++;
	}
}
