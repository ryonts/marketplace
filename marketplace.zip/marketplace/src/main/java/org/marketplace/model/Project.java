package org.marketplace.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Transient;

import javax.persistence.Id;

/** 
 * Represents a Project created by a Seller.  The current price is set from the
 * Seller's budget limit.  Each Bid will reduce this price by an appropriate
 * amount.  When the expiration date occurs, the Project is left with the lowest
 * Bid as its winner.
 * 
 * @author ryonts
 *
 */
@Entity
public class Project {
	@Id
	private Long id;
	private String description;
	private Double amount;
	private Date expiration;
	private Long sellerId;
	@Transient  // deliberately chosen to cut time and effort in this sample project, not ideal in the real world!
	private Bid lowest;
	
	public Project() {
		id = Project.nextSequence();
	}
	public Project(Long sellerId, String description, Double amount, Date expiration) {
		id = Project.nextSequence();
		this.sellerId = sellerId;
		this.description = description;
		this.amount = amount;
		this.expiration = expiration;
		lowest = null;
	}
	
	public Long getId() { return id; }
	public String getDescription() { return description; }
	public Double getAmount() { return amount; }
	public Date getExpiration() { return expiration; }
	public Long getSellerId() { return sellerId; }
	public Double getLowestBidAmount() {		
		if (lowest == null)
			return amount;
		else
			return lowest.getAmount();
	}
	public Bid addNewBid(Bid bid) throws Exception {
		long now = new Date().getTime();
		if (now > expiration.getTime())
			throw new Exception("project date has expired");
		if (lowest == null) {
			if (bid.getAmount() >= amount)
				throw new Exception("bid amount too high");
		} else
			if (bid.getAmount() >= lowest.getAmount())
				throw new Exception("bid amount too high");
		lowest = bid;
		return lowest;
	}

	// ===== class methods to fake out the real database action of autoincrement =====
	private static long sequence = 1000;
	private static long nextSequence() {
		return sequence++;
	}
}
