package org.marketplace.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Seller {
	@Id
	private Long id;
	private String name;
	
	public Seller(Long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Long getId() { return id; }
	public String getName() { return name; }
}
