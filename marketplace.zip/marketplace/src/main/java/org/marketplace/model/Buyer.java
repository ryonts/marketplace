package org.marketplace.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Buyer {
	@Id
	private Long id;
	private String name;
	
	public Buyer(Long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Long getId() { return id; }
	public String getName() { return name; }
}
