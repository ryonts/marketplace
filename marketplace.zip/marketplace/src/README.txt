Marketplace application

This application is a minimal set of ReST endpoints and a somewhat bogus backing store to implement the Intuit backend testing requirement.

The Spring framework is chosen to demonstrate an easy to use, but highly productive, framework that takes care of much of the minutiae, so
that time can be spent on developing useful code.

The frontend portion is represented by a @RestController which defines the endpoints and the basic behavior of each.  The code should be
easily readable by one semi-skilled in the art of Spring development.

The persistence layer is a blend of an expected DAO pattern and some kludgy arrays of String values used to initialize the "database."  It
was decided not to use H2 or MySQL simply to save time and leave the effort of development focused on the frontend and business logic.

Three projects are defined in the "database," with the assumption that these were already created by Buyers.  Some Sellers have bid on the
projects.

Running the application:

To watch the fun in action, run the application within an Eclipse environment.  Import the project and run it by clicking on the
MarketplaceApplication.java file and clicking on the Run button.  The function of adding a new bid can be seen in the unit tests, and further
by running a CURL command such as:

	curl -X POST -H 'content-type:application/json' -d '{"project":"1003", "buyer":"1111", "amount":"18.25"}' http://localhost:8080/project/1003/bid
	
where the project will set its lowest bid amount to $18.25.  This can be verified by running this CURL command:

	curl http://localhost:8080/project/1003/bid
	
To add a new project, run this CURL command:

	curl -X POST -H 'content-type:application/json' -d '{"sellerId":"1010", "description":"cut my hair", "amount":"20", "expiration":"2018-07-25"}' http://localhost:8080/project
	
The rest of endpoints can be exercised in a similar manner.  Here is a sample run of doing a few queries, and then the above commands:

07:51:05$ curl http://localhost:8080/project
[{"id":1000,"description":"paint my house","amount":123.0,"expiration":"2018-07-01T07:00:00.000+0000","sellerId":1000,"lowestBidAmount":123.0},
	{"id":1001,"description":"wash my dishes","amount":15.5,"expiration":"2018-07-04T07:00:00.000+0000","sellerId":1001,"lowestBidAmount":15.5},
	{"id":1002,"description":"mow my lawn","amount":40.1,"expiration":"2018-07-02T07:00:00.000+0000","sellerId":1002,"lowestBidAmount":40.1}]07:51:18$ 
07:51:22$ 
07:51:24$ curl http://localhost:8080/project/1001
{"id":1001,"description":"wash my dishes","amount":15.5,"expiration":"2018-07-04T07:00:00.000+0000","sellerId":1001,"lowestBidAmount":15.5}07:51:34$ 
07:51:35$ 
07:51:38$ curl http://localhost:8080/project/1001/bid
15.507:51:45$ 
07:52:11$
07:52:11$ curl -X POST -H 'content-type:application/json' -d '{"sellerId":"1010", "description":"cut my hair", "amount":"20", "expiration":"2018-07-25"}' http://localhost:8080/project
{"id":1003,"description":"cut my hair","amount":20.0,"expiration":"2018-07-25T00:00:00.000+0000","sellerId":1010,"lowestBidAmount":20.0}07:52:58$ 
07:52:59$ 
07:52:59$ curl -X POST -H 'content-type:application/json' -d '{"project":"1003", "buyer":"1111", "amount":"18.25"}' http://localhost:8080/project/1003/bid
{"id":1007,"project":1003,"buyer":1111,"amount":18.25}07:54:15$ 
07:54:16$ 
07:54:16$

Assessment:

I spent about 3 hours total on the coding, some more on working out this file and cleaning up a few items.  The overall project was fairly straightforward
so I would rate it as moderate at the most.  My feel for the assessment is that it provides a good, meaningful, and clear way to assess the overall idea and
ability of a programmer to work with Spring and ReST.  While I do not believe that I covered all bases (the backend is largely hokey), it would have gone
beyond a simple exercise to make it much more product ready--I chose not to do that in order to keep the focus on the ReST interfaces and their interaction
with the backend parts.  Coding live is a tense item for me; I may spend time looking up exact syntax elements (e.g., @PathVariable or @RequestBody) which is
tricky to do live--I do not memorize these as they are used in short bursts, then not again for weeks/months.  Overall, the process is a good, solid one and
is vastly superior to the online, timed coding puzzles.  Those are interesting, but hardly measure the business coding abilities of a candidate.
